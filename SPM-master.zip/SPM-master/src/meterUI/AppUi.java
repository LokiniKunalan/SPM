/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package meterUI;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import org.apache.commons.lang3.StringUtils;

/**
 *
 * @author Hirusha
 */
public class AppUi extends javax.swing.JFrame {

 
    public AppUi() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jButton1 = new javax.swing.JButton();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jButton1.setText("Calculate Total Comlexity");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jRadioButton1.setText("C++");
        jRadioButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton1ActionPerformed(evt);
            }
        });

        jRadioButton2.setText("JAVA");
        jRadioButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton2ActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(0, 0, 153));

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Complexity Meter");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(289, 289, 289)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 247, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(522, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jButton2.setText("Choose File");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Line No", "Cs_Value", "Ctc_Value", "Cnc_value", "Ci_Value", "Total_Weight", "Cps"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane2.setViewportView(jTable1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 398, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(56, 56, 56)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(50, 50, 50)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jRadioButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jRadioButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 561, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(8, 8, 8)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(48, 48, 48)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 163, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton2)
                        .addGap(18, 18, 18)
                        .addComponent(jRadioButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jRadioButton1)
                        .addGap(30, 30, 30)
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(178, 178, 178))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        String code = jTextArea1.getText();
        if(code.isEmpty()){
          JOptionPane.showMessageDialog(null, "Please Add Some Code Here", "Error", JOptionPane.WARNING_MESSAGE ); 
        }else{
        JOptionPane.showMessageDialog(null, "Currently We don't Have Cnc,Cr Values", "Message", JOptionPane.INFORMATION_MESSAGE ); 
        System.out.println("Total No of Statements :"+countLines(code));
        checkCsKeyWordsJava(code);
        }   
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       JFileChooser chooser = new JFileChooser();
        chooser.showOpenDialog(null);
        File f = chooser.getSelectedFile();
        
        
        String filename = f.getAbsolutePath();
    
        try{

                FileReader reader = new FileReader(filename);
                BufferedReader br = new BufferedReader(reader);
                jTextArea1.read(br, null);
                br.close();
                jTextArea1.requestFocus();
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }      
    }//GEN-LAST:event_jButton2ActionPerformed

    
//check how many lines in the code use to create the result array
    public int countLines(String code){
        Matcher m = Pattern.compile("\r\n|\r|\n").matcher(code);
        int lines = 1;
        while (m.find())
        {
            lines ++;
        }
    return lines;
    }
    
    public void checkCsKeyWordsJava(String code){        
        Scanner scanner = new Scanner(code);
                
        String text = code;        
        String getcode = jTextArea1.getText();
        
        int arraySize = countLines(code);  
        
        String CsKeys[] = new String[arraySize];
        String CiKeys[] = new String[arraySize];
        String CtcKeys[] =new String[arraySize];
        String CncKeys[]=new String[arraySize];
        
        int Cs[] = new int[arraySize];
        int Ci[]=new int[arraySize];
        int Ctc[]=new int[arraySize];
        int Cnc[]=new int[arraySize];

//        for(int i = 0; i<arraySize; i++){
//                    Cs[i] = 0;
//                    CsKeys[i] = " ";
//        }
                
        
        String[] lines = text.split("\\r?\\n");        
        int i=0;int j=0,k=0,l=0,total=0;
        if(getcode.contains("class ")){
                 CiKeys[j] = CiKeys[j] + "class ";
                 Ci[j]=(Ci[j]+1)+1;
            }
            
        for(String line : lines){
            
//            if(line.contains("{")||line.contains("}")||line.contains(" ")){
//                Cs[i]=0;
//                Ci[j]=0;
//                Ctc[k]=0;
//                Cnc[l]=0;
//            }
            
            if(line.contains("&")){
                CsKeys[i] = CsKeys[i] + "& ";
                Cs[i] = Cs[i] + 2;
            }
            if(line.contains("new")){
                CsKeys[i] = CsKeys[i] + "new ";
                Cs[i] = Cs[i] + 2;
            }
            if(line.contains("delete")){
                CsKeys[i] = CsKeys[i] + "delete ";
                Cs[i] = Cs[i] + 2;
            }
            if(line.contains("throw")){
                CsKeys[i] = CsKeys[i] + "throw ";
                Cs[i] = Cs[i] + 2;
            }
            if(line.contains("throws")){
                CsKeys[i] = CsKeys[i] + "throws ";
                Cs[i] = Cs[i] + 2;
            }
            if(line.contains("void")){
                CsKeys[i] = CsKeys[i] + "void ";
                Cs[i] = Cs[i] + 1;
            }
            
            if(line.contains("double")){
                CsKeys[i] = CsKeys[i] + "double ";
                Cs[i] = Cs[i] + 1;
            }
            if(line.contains("int")){
                CsKeys[i] = CsKeys[i] + "int ";
                Cs[i] = Cs[i] + 1;
            }
            if(line.contains("float")){
                CsKeys[i] = CsKeys[i] + "float ";
                Cs[i] = Cs[i] + 1;
            }
            if(line.contains("string")){
                CsKeys[i] = CsKeys[i] + "string ";
                Cs[i] = Cs[i] + 1;
            }
            if(line.contains("printf")){
                CsKeys[i] = CsKeys[i] + "printf ";
                Cs[i] = Cs[i] + 1;
            }
            if(line.contains("System ")){
                CsKeys[i] = CsKeys[i] + "System ";
                Cs[i] = Cs[i] + 1;
            }
            if(line.contains(". ")){
                CsKeys[i] = CsKeys[i] + ". ";
                Cs[i] = Cs[i] + 1;
            }
            if(line.contains("out")){
                CsKeys[i] = CsKeys[i] + "out ";
                Cs[i] = Cs[i] + 1;
            }
            if(line.contains("println")){
                CsKeys[i] = CsKeys[i] + "println ";
                Cs[i] = Cs[i] + 1;
            }
            if(line.contains("print")){
                CsKeys[i] = CsKeys[i] + "print ";
                Cs[i] = Cs[i] + 1;
            }
            if(line.contains("cout")){
                CsKeys[i] = CsKeys[i] + "cout ";
                Cs[i] = Cs[i] + 1;
            }
            if(line.contains("cin")){
                CsKeys[i] = CsKeys[i] + "cin ";
                Cs[i] = Cs[i] + 1;
            }
            if(line.contains("if")){
                CsKeys[i] = CsKeys[i] + "if ";
                CtcKeys[k]=CtcKeys[k] +"if ";
                Cs[i] = Cs[i] + 1;
                Ctc[k]=Ctc[k]+1;
            }
            if(line.contains("for")){
                CsKeys[i] = CsKeys[i] + "for ";
                CtcKeys[k]=CtcKeys[k] +"for ";
                Cs[i] = Cs[i] + 1;
                Ctc[k]=Ctc[k]+2;
            }
            if(line.contains("while")){
                CsKeys[i] = CsKeys[i] + "while ";
                CtcKeys[k]=CtcKeys[k] +"while ";
                Cs[i] = Cs[i] + 1;
                Ctc[k]=Ctc[k]+2;
            }
            if(line.contains("do")){
                CsKeys[i] = CsKeys[i] + "do ";
                Cs[i] = Cs[i] + 1;
                CtcKeys[k]=CtcKeys[k] +"do  ";
                Ctc[k]=Ctc[k]+2;
            }
            if(line.contains("switch")){
                CsKeys[i] = CsKeys[i] + "switch ";
                Cs[i] = Cs[i] + 1;
                CtcKeys[k]=CtcKeys[k] +"switch  ";
                Ctc[k]=Ctc[k]+k;
            }
            if(line.contains("case")){
                CsKeys[i] = CsKeys[i] + "case ";
                Cs[i] = Cs[i] + 1;
            }
            if(line.contains("endl’")){
                CsKeys[i] = CsKeys[i] + "endl ";
                Cs[i] = Cs[i] + 1;
            }
            if(line.contains("'")){
                CsKeys[i] = CsKeys[i] + "' ";
                Cs[i] = Cs[i] + 1;
            }
            if(line.contains("+")){
                if(line.contains("++")){
                CsKeys[i] = CsKeys[i] + "++ ";
                Cs[i] = Cs[i] + 1;
                }
                else if(line.contains("+=")){
                CsKeys[i] = CsKeys[i] + "+= ";
                Cs[i] = Cs[i] + 1;
                }
                else{
                CsKeys[i] = CsKeys[i] + "+ ";
                Cs[i] = Cs[i] + 1;
                }
            }
            if(line.contains("-")){
                if(line.contains("--")){
                CsKeys[i] = CsKeys[i] + "-- ";
                Cs[i] = Cs[i] + 1;
                }
                else if(line.contains("->")){
                CsKeys[i] = CsKeys[i] + "-> ";
                Cs[i] = Cs[i] + 1;
                }
                else if(line.contains("-=")){
                CsKeys[i] = CsKeys[i] + "-= ";
                Cs[i] = Cs[i] + 1;
                }
                else{
                CsKeys[i] = CsKeys[i] + "- ";
                Cs[i] = Cs[i] + 1;
                }
            }
            if(line.contains("=")){
                if(line.contains("==")){
                CsKeys[i] = CsKeys[i] + "== ";
                Cs[i] = Cs[i] + 1;
                }
                else{
                CsKeys[i] = CsKeys[i] + "= ";
                Cs[i] = Cs[i] + 1;
                }
            }
            if(line.contains("!")){
                if(line.contains("!=")){
                CsKeys[i] = CsKeys[i] + "!= ";
                Cs[i] = Cs[i] + 1;
                }
                else{
                CsKeys[i] = CsKeys[i] + "! ";
                Cs[i] = Cs[i] + 1;
                }
            }
            if(line.contains(">")){
                if(line.contains(">=")){
                CsKeys[i] = CsKeys[i] + ">= ";
                Cs[i] = Cs[i] + 1;
                }
                else if(line.contains(">>=")){
                CsKeys[i] = CsKeys[i] + ">>= ";
                Cs[i] = Cs[i] + 1;
                }
                else if(line.contains(">>>=")){
                CsKeys[i] = CsKeys[i] + ">>>= ";
                Cs[i] = Cs[i] + 1;
                }
                else if(line.contains(">>>")){
                CsKeys[i] = CsKeys[i] + ">>> ";
                Cs[i] = Cs[i] + 1;
                }
                else if(line.contains(">>")){
                CsKeys[i] = CsKeys[i] + ">> ";
                Cs[i] = Cs[i] + 1;
                }
                else{
                CsKeys[i] = CsKeys[i] + "> ";
                Cs[i] = Cs[i] + 1;
                }
            }
            if(line.contains("<")){
                if(line.contains("<=")){
                CsKeys[i] = CsKeys[i] + "<= ";
                Cs[i] = Cs[i] + 1;
                }
                else if(line.contains("<<=")){
                CsKeys[i] = CsKeys[i] + "<<= ";
                Cs[i] = Cs[i] + 1;
                }
                else if(line.contains("<<<=")){
                CsKeys[i] = CsKeys[i] + "<<<= ";
                Cs[i] = Cs[i] + 1;
                }
                else if(line.contains("<<<")){
                CsKeys[i] = CsKeys[i] + "<<< ";
                Cs[i] = Cs[i] + 1;
                }
                else if(line.contains("<<")){
                CsKeys[i] = CsKeys[i] + "<< ";
                Cs[i] = Cs[i] + 1;
                }
                else{
                CsKeys[i] = CsKeys[i] + "< ";
                Cs[i] = Cs[i] + 1;
                }
            }
            if(line.contains("* ")){
                if(line.contains("*=")){
                CsKeys[i] = CsKeys[i] + "*= ";
                Cs[i] = Cs[i] + 1;
                }
                //code for poiner
                //else if(line.contains("**")){
                //CsKeys[i] = CsKeys[i] + "** ";
                //Cs[i] = Cs[i] + 1;
                //}
                else{
                CsKeys[i] = CsKeys[i] + "* ";
                Cs[i] = Cs[i] + 1;
                }
            }
            if(line.contains("/")){
                if(line.contains("/=")){
                CsKeys[i] = CsKeys[i] + "/= ";
                Cs[i] = Cs[i] + 1;
                }
                else{
                CsKeys[i] = CsKeys[i] + "/ ";
                Cs[i] = Cs[i] + 1;
                }
            }
            if(line.contains("|")){
                if(line.contains("|=")){
                CsKeys[i] = CsKeys[i] + "|= ";
                Cs[i] = Cs[i] + 1;
                }
                else{
                CsKeys[i] = CsKeys[i] + "| ";
                Cs[i] = Cs[i] + 1;
                }
            }
            if(line.contains("%")){
                if(line.contains("%=")){
                CsKeys[i] = CsKeys[i] + "%= ";
                Cs[i] = Cs[i] + 1;
                }
                else{
                CsKeys[i] = CsKeys[i] + "% ";
                Cs[i] = Cs[i] + 1;
                }
            }
            if(line.contains(":")){
                if(line.contains("::")){
                CsKeys[i] = CsKeys[i] + ":: ";
                Cs[i] = Cs[i] + 1;
                }
                else{
                CsKeys[i] = CsKeys[i] + ": ";
                Cs[i] = Cs[i] + 1;
                }
            }
            if(line.contains("^")){
                if(line.contains("^=")){
                CsKeys[i] = CsKeys[i] + "^= ";
                Cs[i] = Cs[i] + 1;
                }
                else{
                CsKeys[i] = CsKeys[i] + "^ ";
                Cs[i] = Cs[i] + 1;
                }
            }
            
        DefaultTableModel dt=(DefaultTableModel)jTable1.getModel();
        
        Vector v=new Vector();
        v.add(i+1);
        v.add(Cs[i]);
        v.add(Ctc[k]);
        v.add(Cnc[l]);
        v.add(Ci[j]);
        total=Ctc[k]+Ci[j]+Cnc[l];
        v.add(total);
        v.add(total*Cs[i]);
        
        dt.addRow(v);
//            System.out.print("Cs of Line No "+(i+1)+"\t  : \t");
//            System.out.print(Cs[i]+"\t");
//            System.out.println(Ci[j]);
            
        
         
            i = i + 1;k=k+1;l=l+1; 
            //j=j+1
        }   

    }
    
    public void checkCtcKeyWordJava(String code){
    
      final List<String> bitwise = Arrays.asList(" && ", " || ", " & ", " | ");
      final List<String> ccs = Arrays.asList("if(", "catch(", "if (", "catch (");
      final List<String> ics = Arrays.asList("for(", "while(", "for (", "while (");  
    //  static statement switchLine = null;
      int switchCtc = 0;
      int ctc = 0; 
      
    Scanner fileInput = new Scanner(code);  
    while ( fileInput.hasNextLine())  {
       String line = fileInput.nextLine();
       
       line = line.trim();
       for (String keyword : ccs) {
            if (!line.isEmpty() && line.indexOf(keyword) != -1) {
                
               ctc += StringUtils.countMatches(line, keyword);
                for (String bw : bitwise) {
                    ctc += StringUtils.countMatches(line, bw);
                }
            }
        }
        for (String keyword : ics) {
            if (!line.isEmpty() && line.indexOf(keyword) != -1) {
               ctc += StringUtils.countMatches(line, keyword) * 2;
                for (String bw : bitwise) {
                   ctc += StringUtils.countMatches(line, bw) * 2;
                }
            }
        }
        switchCtc += StringUtils.countMatches(line, "case");
    }
    fileInput.close();
    }
    



    private void jRadioButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton2ActionPerformed

        jRadioButton1.setSelected(false);
    }//GEN-LAST:event_jRadioButton2ActionPerformed

    private void jRadioButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton1ActionPerformed
        jRadioButton2.setSelected(false);
    }//GEN-LAST:event_jRadioButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AppUi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AppUi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AppUi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AppUi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AppUi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextArea jTextArea1;
    // End of variables declaration//GEN-END:variables
}
